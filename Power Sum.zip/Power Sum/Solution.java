import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class Solution {

    // Complete the powerSum function below.
    static int powerSum(int X, int N) {
        int cnt, totalcnt =0;
        //for(int i=1;i<=10;i++){
            cnt = findPowerSum(X, N, 1);
            totalcnt += cnt;
            System.out.println(cnt);
        //}
        return totalcnt;
    }

    static public int findPowerSum(int total, int power, int num)
    {
        int value = total - (int) Math.pow(num, power);
        
        if(value < 0) return 0;
        else if(value == 0) return 1;
        else return findPowerSum(value , power, num + 1) +
                    findPowerSum(total, power, num+1);
    }

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws IOException {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(System.getenv("OUTPUT_PATH")));

        int X = scanner.nextInt();
        scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

        int N = scanner.nextInt();
        scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

        int result = powerSum(X, N);

        bufferedWriter.write(String.valueOf(result));
        bufferedWriter.newLine();

        bufferedWriter.close();

        scanner.close();
    }
}
